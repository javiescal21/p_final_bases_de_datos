-- Crear una vista temporal con los datos base
CREATE OR REPLACE VIEW temp_observations AS
SELECT 
    o.id,
    o.observed_on,
    l.latitude,
    l.longitude,
    l.timezone,
    da.temperature_2m,
    da.precipitation,
    da.cloudcover,
    da.windspeed_10m,
    tn.scientific_name,
    p.geoprivacy
FROM observations o
JOIN locations l ON o.locations_id = l.id
JOIN taxonomy t ON o.taxonomy_id = t.id
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN datos_ambientales da ON o.id = da.observations_id
JOIN privacy p ON o.id = p.observations_id;

-- Atributos temporales
ALTER TABLE observations ADD COLUMN IF NOT EXISTS season TEXT;
ALTER TABLE observations ADD COLUMN IF NOT EXISTS is_night BOOLEAN;
ALTER TABLE observations ADD COLUMN IF NOT EXISTS day_of_week INTEGER;

UPDATE observations 
SET 
    season = CASE 
        WHEN EXTRACT(MONTH FROM observed_on) IN (12, 1, 2) THEN 'Winter'
        WHEN EXTRACT(MONTH FROM observed_on) IN (3, 4, 5) THEN 'Spring'
        WHEN EXTRACT(MONTH FROM observed_on) IN (6, 7, 8) THEN 'Summer'
        ELSE 'Fall'
    END,
    day_of_week = EXTRACT(DOW FROM observed_on)::INTEGER;

-- Atributos de densidad espacial (con ofuscación)
CREATE OR REPLACE VIEW species_density AS
SELECT 
    -- Redondeamos las coordenadas para proteger ubicaciones exactas
    TRUNC(latitude::numeric, 1) AS lat_grid,
    TRUNC(longitude::numeric, 1) AS lon_grid,
    scientific_name,
    COUNT(*) AS observation_count,
    -- Agregamos ruido aleatorio a las métricas
    TRUNC((AVG(temperature_2m) + (RANDOM() - 0.5))::numeric, 1) AS avg_temperature,
    TRUNC((AVG(precipitation) + (RANDOM() - 0.5))::numeric, 2) AS avg_precipitation
FROM temp_observations
WHERE geoprivacy != 'private'  -- Respetamos la privacidad
GROUP BY 
    TRUNC(latitude::numeric, 1),
    TRUNC(longitude::numeric, 1),
    scientific_name
HAVING COUNT(*) >= 5;  -- Solo mostramos áreas con suficientes observaciones

-- Atributos de comportamiento por temporada
CREATE OR REPLACE VIEW species_behavior AS
SELECT 
    tn.scientific_name,
    o.season,
    TRUNC(AVG(da.temperature_2m)::numeric, 1) AS preferred_temperature,
    TRUNC(AVG(da.precipitation)::numeric, 2) AS preferred_precipitation,
    TRUNC(AVG(da.cloudcover)::numeric, 1) AS preferred_cloudcover,
    COUNT(*) AS observation_count
FROM observations o
JOIN taxonomy t ON o.taxonomy_id = t.id
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN datos_ambientales da ON o.id = da.observations_id
GROUP BY tn.scientific_name, o.season
HAVING COUNT(*) >= 10;  -- Aseguramos suficientes datos para patrones significativos

-- Índice de vulnerabilidad (ejemplo simplificado)
CREATE OR REPLACE VIEW species_vulnerability AS
SELECT 
    tn.scientific_name,
    COUNT(DISTINCT l.timezone) AS habitat_zones,
    COUNT(*) AS total_observations,
    COUNT(DISTINCT EXTRACT(MONTH FROM o.observed_on)::INTEGER) AS active_months,
    CASE 
        WHEN COUNT(*) < 20 THEN 'High'
        WHEN COUNT(*) < 50 THEN 'Medium'
        ELSE 'Low'
    END AS vulnerability_level
FROM observations o
JOIN taxonomy t ON o.taxonomy_id = t.id
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN locations l ON o.locations_id = l.id
GROUP BY tn.scientific_name;


