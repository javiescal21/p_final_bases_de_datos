BEGIN;

-- 1. Llenar taxonomy_names
ALTER SEQUENCE taxonomy_names_id_seq RESTART WITH 1;
INSERT INTO taxonomy_names (scientific_name, common_name)
SELECT DISTINCT scientific_name, common_name
FROM raw.reduccion_limpia;

-- 2. Llenar taxonomy
ALTER SEQUENCE taxonomy_id_seq RESTART WITH 1;
INSERT INTO taxonomy (taxon_id, taxonomy_nombres_id)
SELECT DISTINCT rl.taxon_id, tn.id 
FROM raw.reduccion_limpia rl
JOIN taxonomy_names tn ON rl.scientific_name = tn.scientific_name;

-- 3. Llenar locations
ALTER SEQUENCE locations_id_seq RESTART WITH 1;
INSERT INTO locations (latitude, longitude, timezone)
SELECT DISTINCT latitude, longitude, time_zone
FROM raw.reduccion_limpia;

-- 3. Llenar observations
ALTER SEQUENCE observations_id_seq RESTART WITH 1;
INSERT INTO observations (observed_on, locations_id, taxonomy_id)
SELECT 
	rl.observed_on,
	    loc.id AS locations_id,
	    tax.id AS taxonomy_id
	FROM raw.reduccion_limpia rl
	JOIN locations loc
	ON rl.latitude = loc.latitude AND rl.longitude = loc.longitude AND rl.time_zone = loc.timezone
	JOIN taxonomy tax
	ON rl.taxon_id = tax.taxon_id;

-- 6. Llenar privacy
ALTER SEQUENCE privacy_id_seq RESTART WITH 1;
INSERT INTO privacy (license, geoprivacy, taxon_geoprivacy, observations_id) 
SELECT 
    rl.license,
    rl.geoprivacy,
    rl.taxon_geoprivacy,
    obs.id AS observations_id
FROM raw.reduccion_limpia rl
JOIN observations obs
ON rl.observed_on = obs.observed_on
JOIN locations loc
ON obs.locations_id = loc.id -- Relación entre observations y locations
AND rl.latitude = loc.latitude -- Verificación con coordinates
AND rl.longitude = loc.longitude;



SELECT observed_on, locations_id, COUNT(*)
FROM observations
GROUP BY observed_on, locations_id
HAVING COUNT(*) > 1;


SELECT observed_on, COUNT(*)
FROM observations
GROUP BY observed_on
HAVING COUNT(*) > 1;

SELECT observed_on, COUNT(*)
FROM raw.reduccion_limpia
GROUP BY observed_on
HAVING COUNT(*) > 1;



SELECT *
FROM observations
ORDER BY id;

SELECT observed_on, latitude, longitude, COUNT(*)
FROM raw.reduccion_limpia
GROUP BY observed_on, latitude, longitude
HAVING COUNT(*) > 1;



-- 7. Llenar datos_ambientales
ALTER SEQUENCE datos_ambientales_id_seq RESTART WITH 1;
INSERT INTO datos_ambientales (temperature_2m, precipitation, cloudcover, windspeed_10m, observations_id)
SELECT 
    rl.temperature_2m,
    rl.precipitation,
    rl.cloudcover,
    rl.windspeed_10m,
    obs.id AS observations_id
FROM raw.reduccion_limpia rl
JOIN observations obs
ON rl.observed_on = obs.observed_on;



COMMIT;
ROLLBACK;