DROP SCHEMA IF EXISTS tablas_intuitivas CASCADE;
CREATE SCHEMA IF NOT EXISTS tablas_intuitivas; 


-- Tabla Taxonomy
DROP TABLE IF EXISTS tablas_intuitivas.taxonomy;
CREATE TABLE tablas_intuitivas.taxonomy (
    id BIGSERIAL PRIMARY KEY,
    scientific_name VARCHAR(100) NOT NULL,
    common_name VARCHAR(100),
    taxon_id BIGINT NOT NULL
);

-- Tabla Observations
DROP TABLE IF EXISTS tablas_intuitivas.observations;
CREATE TABLE tablas_intuitivas.observations (
    id BIGSERIAL PRIMARY KEY,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    observed_on DATE NOT NULL,
    timezone VARCHAR(100) NOT NULL,
    taxonomy_id BIGINT NOT NULL REFERENCES tablas_intuitivas.taxonomy(id)
);

-- Tabla Privacy
DROP TABLE IF EXISTS tablas_intuitivas.privacy;
CREATE TABLE tablas_intuitivas.privacy (
    id BIGSERIAL PRIMARY KEY,
    license VARCHAR(50) DEFAULT 'No license registered',
    geoprivacy VARCHAR(50) DEFAULT 'open',
    taxon_geoprivacy VARCHAR(50) DEFAULT 'private',
    observations_id BIGINT NOT NULL UNIQUE REFERENCES tablas_intuitivas.observations(id)
);

-- Tabla Datos Ambientales
DROP TABLE IF EXISTS ptablas_intuitivas.datos_ambientales;
CREATE TABLE tablas_intuitivas.datos_ambientales (
    id BIGSERIAL PRIMARY KEY,
    temperatura_2m DOUBLE PRECISION NOT NULL,
    precipitation DOUBLE PRECISION NOT NULL,
    cloudcover DOUBLE PRECISION NOT NULL,
    windspeed_10m DOUBLE PRECISION NOT NULL,
    observations_id BIGINT NOT NULL UNIQUE REFERENCES tablas_intuitivas.observations(id)
);