-- Análisis

-- 5.1 geoprivacidad y especie
SELECT 
    tn.scientific_name,
    tn.common_name
FROM taxonomy t
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN observations o ON t.id = o.taxonomy_id
JOIN privacy p ON o.id = p.observations_id
WHERE p.geoprivacy = 'obscured'
GROUP BY tn.scientific_name, tn.common_name;

SELECT
    tn.scientific_name,
    tn.common_name,
    COUNT(CASE WHEN p.license IS NOT NULL THEN 1 END) AS licensed_observations
FROM taxonomy t
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN observations o ON t.id = o.taxonomy_id
JOIN privacy p ON o.id = p.observations_id
WHERE p.geoprivacy = 'obscured'
GROUP BY tn.scientific_name, tn.common_name
HAVING COUNT(CASE WHEN p.license IS NOT NULL THEN 1 END) > 0
ORDER BY licensed_observations DESC;

SELECT
    tn.scientific_name,
    tn.common_name,
    COUNT(DISTINCT p.geoprivacy) AS unique_geoprivacy_settings
FROM taxonomy t
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN observations o ON t.id = o.taxonomy_id
JOIN privacy p ON o.id = p.observations_id
WHERE tn.scientific_name IN (
    SELECT tn.scientific_name
    FROM taxonomy t
    JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
    JOIN observations o ON t.id = o.taxonomy_id
    JOIN privacy p ON o.id = p.observations_id
    WHERE p.geoprivacy = 'obscured'
    GROUP BY tn.scientific_name
)
GROUP BY tn.scientific_name, tn.common_name
HAVING COUNT(DISTINCT p.geoprivacy) > 1;

-- 5.2 geoprivacy throughout time
SELECT
    tn.scientific_name,
    tn.common_name,
    p.geoprivacy,
    o.observed_on,
    l.timezone,
    l.latitude,
    l.longitude
FROM taxonomy t
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN observations o ON t.id = o.taxonomy_id
JOIN privacy p ON o.id = p.observations_id
JOIN locations l ON o.locations_id = l.id
WHERE t.id IN (
    SELECT t.id
    FROM taxonomy t
    JOIN observations o ON t.id = o.taxonomy_id
    JOIN privacy p ON o.id = p.observations_id
    GROUP BY t.id
    HAVING COUNT(DISTINCT p.geoprivacy) > 1
)
ORDER BY tn.scientific_name, o.observed_on;

SELECT
    tn.scientific_name,
    tn.common_name,
    o.observed_on,
    p.geoprivacy,
    CASE
        WHEN LAG(p.geoprivacy, 1) OVER (PARTITION BY tn.scientific_name ORDER BY o.observed_on) IS DISTINCT FROM p.geoprivacy THEN 'Changed'
        ELSE 'No change'
    END AS geoprivacy_change
FROM taxonomy t
JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
JOIN observations o ON t.id = o.taxonomy_id
JOIN privacy p ON o.id = p.observations_id
WHERE tn.scientific_name IN (
    SELECT tn.scientific_name
    FROM taxonomy t
    JOIN taxonomy_names tn ON t.taxonomy_nombres_id = tn.id
    JOIN observations o ON t.id = o.taxonomy_id
    JOIN privacy p ON o.id = p.observations_id
    GROUP BY tn.scientific_name
    HAVING COUNT(DISTINCT p.geoprivacy) > 1
)
ORDER BY tn.scientific_name, o.observed_on;

-- 5.3 frecuencia y distribución

-- distribución:
ALTER TABLE observations
ADD COLUMN year INT;
UPDATE observations
SET year = EXTRACT(YEAR FROM observed_on);

SELECT 
    tn.scientific_name, 
    o.year,
    MAX(l.latitude) as max_lat,
    MIN(l.latitude) as min_lat,
    MAX(l.longitude) as max_long,
    MIN(l.longitude) as min_long,
    COUNT(DISTINCT l.timezone) as num_regions,
    COUNT(o.*) as num_observations
FROM taxonomy_names tn 
JOIN taxonomy t ON t.taxonomy_nombres_id = tn.id
JOIN observations o ON t.id = o.taxonomy_id
JOIN locations l ON o.locations_id = l.id
GROUP BY tn.scientific_name, o.year
HAVING COUNT(o.*) > 3
ORDER BY tn.scientific_name, o.year;








