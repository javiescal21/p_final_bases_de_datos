-- Análisis

-- 5.1 geoprivacidad y especie
SELECT 
    tn.scientific_name,
    tn.common_name
FROM taxonomy t
JOIN taxonomy_names tn ON t.taxonomy_names_id = tn.id
JOIN observations o ON t.id = o.taxonomy_id
JOIN privacy p ON o.id = p.observations_id
WHERE p.geoprivacy = 'obscured'
GROUP BY tn.scientific_name, tn.common_name;







